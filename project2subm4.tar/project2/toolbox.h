#ifndef TOOLBOX
#define TOOLBOX
 
#include <iostream>
#include <cstring>
 
using namespace std;
 
//function prototypes
int readInt(const char prompt[]);
void readString (const char prompt[], char inputStr[], int maxChar);

//named constants
const int MAX_CHAR = 101; 

#endif
