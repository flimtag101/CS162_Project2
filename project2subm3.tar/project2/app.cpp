/*******************************************************************************
 ** Program Name:   app.cpp
 ** Author:         Alex Elliott
 ** Date:           01/31/2020
 ** Assignment:     Project 02
 ** Description:    This program simulates an interative song menu.
 ** Sources:        https://docs.google.com/document/d/1YUGplC91tkfBKBEQWMOHkyP
 **                 fZUrr5vKddCDQfOXZ5Ho/edit?pli=1
 **                 https://docs.google.com/presentation/d/1hgsfZ2OEZFbkXa5fUP0
 **                 XCUS-ypOZ_3kB01cE_bQIppw/edit?pli=1#slide=id.g7cf411cf47_0_6
 **                 Note: Always cite all sources you may have used, such
 **                 as other students you may have had help from, web sites you
 **                 may have referenced, and so forth. If none, write None.
 *******************************************************************************/

#include <iostream> //Required if your program does any I/O
#include <string>    
#include <cctype>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "toolbox.h"

using namespace std; //Required if your program has any output

//declare public constants
const int INDEX_COL_WIDTH = 1;
const int TITLE_COL_WIDTH = 25;
const int ARTIST_COL_WIDTH = 25;
const int DURATION_COL_WIDTH = 17;
const int ALBUM_COL_WIDTH = 23;
const int SONG_CAPACITY = 50;
const int TEMP_SIZE = 5;

struct Song
{
  char title[MAX_CHAR];
  char artist[MAX_CHAR];
  int minutes;
  int seconds;
  char album[MAX_CHAR];
};

//user-interface related functions
void displayMenu();
void displayHeader();
char readInCommand();
void processCommand(char command, Song list[], int& listSize);
void readInEntry(Song& anEntry);
void readInArtist(char artist[]);
void readInAlbum(char album[]);

////database related functions
void displayAll(const Song list[], const Song match[], int listSize);
void addEntry(const Song & anEntry, Song list[], int & listSize);
void digitToChar(const Song list[], int index, char temp[TEMP_SIZE]);
void deleteEntry(const int index, Song list[], int & listSize);
bool searchArtistEntry(const char artist[], Song match[],
const Song list[], char duration[TEMP_SIZE], int listSize);
bool searchAlbumEntry(const char album[], Song match[], 
const Song list[], char tempDuration[TEMP_SIZE], int listSize);
//void nullCap(char lowerAlbum[MAX_CHAR], const Song list[])
void readDuration(int& mins, int& secs);

//use external file
void loadSongLibrary(const char fileName[],
Song list[], int & listSize);
void saveSongLibrary(const char fileName[],
const Song list[], int listSize);

int main() 
{
    char command;
    Song list[SONG_CAPACITY];
    int listSize = 0;
    char fileName[] = "songs.txt";
    
    //load song library
    loadSongLibrary(fileName, list, listSize);

    displayMenu();
    command = readInCommand();
    while(command != 'q')
    {
        processCommand(command, list, listSize);
        displayMenu();
        command = readInCommand();
    }
    cout << command;

    //write out file
    saveSongLibrary(fileName, list, listSize);

    cout << endl << "Thank you for using ElliottPlayer!" << endl;
    return 0;
}

void displayMenu() 
{
        cout << "Welcome to ElliottPlayer!" << endl;
        cout << "a: add an entry" << endl;
        cout << "d: delete an entry" << endl;
        cout << "l: list all the entries" << endl;
        cout << "r: search library by artist" << endl;
        cout << "b: search library by album" << endl;
        cout << "q: exit the program" << endl;
}

char readInCommand() 
{
    char cmd;

    cout << endl << "Please enter the command (a,d,l,r,b or q): ";
    cin >> cmd;
    cin.ignore(100, '\n');

    return tolower(cmd);
}

void processCommand(char command, Song list[], int& listSize)
{
    Song entry;
    Song match[SONG_CAPACITY];
    char artist[MAX_CHAR];
    char album[MAX_CHAR];
    char duration[TEMP_SIZE];
    int usrIndex;

    switch (command)
    {
        case 'a':
            readInEntry(entry);
            addEntry(entry, list, listSize);
            break;
        case 'd':
            usrIndex = readInt("Enter index of song to delete: ");
            deleteEntry(usrIndex, list, listSize);
            break;
        case 'l':
            displayAll(list, match, listSize);
            break;
        case 'r':
            readInArtist(artist);
            //determines whether artist name exists
            if(searchArtistEntry(artist, match, list, duration, listSize))
            {
                displayAll(match, list, listSize);
                /*cout << i+1 << setw(TITLE_COL_WIDTH) << entry.title <<
                setw(ARTIST_COL_WIDTH) << entry.artist <<
                setw(DURATION_COL_WIDTH) << duration << 
                setw(ALBUM_COL_WIDTH) << entry.album << endl;*/

            }
            else
            {
                cout << endl << "The artist named " <<
                artist << " doesn't exist!" << endl << endl;
            }
            break;
        case 'b':
            readInAlbum(album);
            //determines whether album name exists
            if(searchAlbumEntry(album, match, list, duration, listSize))
            {
                displayAll(match, list, listSize);
                /*cout << i+1 << setw(TITLE_COL_WIDTH) << entry.title <<
                setw(ARTIST_COL_WIDTH) << entry.artist <<
                setw(DURATION_COL_WIDTH) << duration << 
                setw(ALBUM_COL_WIDTH) << entry.album << endl;*/

            }
            else
            {
                cout << endl << "The album named " << album <<
                " doesn't exist!" << endl << endl;
            }
            break;
        default:
            cout << endl << "Not a valid entry!" << endl << endl;
            break;
    }
}

void readInEntry(Song& anEntry)
{
    char title[MAX_CHAR];
    char artist[MAX_CHAR];
    char album[MAX_CHAR];
    int minutes;
    int seconds;

    readString("Please enter the title: ", title, MAX_CHAR);
    readString("Please enter the artist: ", artist, MAX_CHAR);
    readDuration(minutes, seconds);
    readString("Please enter the album: ", album, MAX_CHAR);
    cout << endl;

    strcpy(anEntry.title, title);
    strcpy(anEntry.artist, artist); 
    anEntry.minutes = minutes;
    anEntry.seconds = seconds;
    strcpy(anEntry.album, album);
}

void readDuration(int& mins, int& secs)
{
    mins = -1;
    secs = -1;

    while (mins < 0)
    {
        mins = readInt("Please enter the minutes: ");
        if (mins < 0)
            cout << "ERROR: minutes must be a positive value!" << endl;
    }

    while (secs > 59 || secs < 0)
    {
        secs = readInt("Please enter the seconds: ");
        if (secs > 59 || secs < 0)
            cout << "ERROR: seconds must be between 0 and 59!" << endl;
    }
}

void digitToChar(const Song list[], int index, char temp[TEMP_SIZE])
{
    temp[0] = '0' + list[index].minutes / 10;
    temp[1] = '0' + list[index].minutes % 10;
    temp[2] = ':';
    temp[3] = '0' + list[index].seconds / 10;
    temp[4] = '0' + list[index].seconds % 10; 
    temp[5] = '\0';
}

void addEntry(const Song & anEntry, Song list[], int & listSize)
{
    strcpy(list[listSize].title, anEntry.title);
    strcpy(list[listSize].artist, anEntry.artist);
    list[listSize].minutes = anEntry.minutes;
    list[listSize].seconds = anEntry.seconds;
    strcpy(list[listSize].album, anEntry.album);
    listSize++;
}

void displayHeader()
{
    cout << setw(INDEX_COL_WIDTH) << "#" << setw(TITLE_COL_WIDTH) <<
    "Title" << setw(ARTIST_COL_WIDTH) << "Artist" <<
    setw(DURATION_COL_WIDTH) << "Duration" <<
    setw(ALBUM_COL_WIDTH) << "Album" << endl;
    cout << "----------------------------------------------------";
    cout << "-------------------------------------------" << endl;
}

void displayAll(const Song list[], const Song match[], int listSize) 
{
    //int checkIndex;
    char temp[TEMP_SIZE];
    bool check = false;

    // prints by song list XOR by search
    /*for (checkIndex = 0; checkIndex < listSize; checkIndex++)
    {
        if ((strcmp(match[checkIndex].artist, 
        list[checkIndex].artist) == 0) || (strcmp(match[checkIndex].album,
        list[checkIndex].album) == 0))
            check = true;
    }*/
    
    displayHeader();

    for (int i = 0; i < listSize; ++i)
    {   
        if (check)
        {
            if ((strcmp(match[i].artist, list[i].artist) == 0) || 
            (strcmp(match[i].album, list[i].album) == 0))
            {
                // converts mins and secs to char array
                temp[0] = '0' + list[i].minutes / 10;
                temp[1] = '0' + list[i].minutes % 10;
                temp[2] = ':';
                temp[3] = '0' + list[i].seconds / 10;
                temp[4] = '0' + list[i].seconds % 10; 
                temp[5] = '\0';

                cout << i+1 << setw(TITLE_COL_WIDTH) << list[i].title <<
                setw(ARTIST_COL_WIDTH) << list[i].artist <<
                setw(DURATION_COL_WIDTH);
        
                for (int j = 0; j < 5; ++j)
                    cout << temp[j];

                cout << setw(ALBUM_COL_WIDTH) << list[i].album << endl;
            }
        }
        else
        {
            // converts mins and secs to char array
            temp[0] = '0' + list[i].minutes / 10;
            temp[1] = '0' + list[i].minutes % 10;
            temp[2] = ':';
            temp[3] = '0' + list[i].seconds / 10;
            temp[4] = '0' + list[i].seconds % 10; 
            temp[5] = '\0';

            cout << i+1 << setw(TITLE_COL_WIDTH) << list[i].title <<
            setw(ARTIST_COL_WIDTH) << list[i].artist <<
            setw(DURATION_COL_WIDTH);
        
            for (int j = 0; j < 5; ++j)
                cout << temp[j];

            cout << setw(ALBUM_COL_WIDTH) << list[i].album << endl;
        }
    }
    check = false;
    cout << endl;
}

void deleteEntry(int index, Song list[], int & listSize)
{ 
    if (index <= listSize)
    {
        //shift conveyor belt left
        for (int i = index - 1; i <= listSize; ++i)
        {
            list[i] = list[i + 1];
        }
        listSize--;
    }
    else
    {
        cout << index << "is outside the song index!" << endl;
    }
}

void readInArtist(char artist[])
{
    readString("Please enter the artist you want to search: ",
    artist, MAX_CHAR);
}

void readInAlbum(char album[])
{
    readString("Please enter the album you want to search: ",
    album, MAX_CHAR);
}

bool searchAlbumEntry(const char album[], Song match[],
const Song list[], char tempDuration[TEMP_SIZE], int listSize)
{
    int albumIndex, inputIndex, index;
    char albumLower[MAX_CHAR];
    //char inputLower[MAX_CHAR];
    
    // sets input to lower case using temporary array
    for (inputIndex = 0; inputIndex <= MAX_CHAR; inputIndex++)
        albumLower[inputIndex] = tolower(album[inputIndex]);

    for (index = 0; index < listSize; index++)
    {
        // sets song list album array to lower case
        for (albumIndex = 0; albumIndex <= MAX_CHAR; albumIndex++)
        {
            match[index].album[albumIndex] = tolower
            (list[index].album[albumIndex]);
        }

        if(strcmp(albumLower, match[index].album) == 0)
        {
            strcpy(match[index].album, list[index].album);
            strcpy(match[index].title, list[index].title); 
            digitToChar(list, index, tempDuration);
            match[index].minutes = list[index].minutes;
            match[index].seconds = list[index].seconds;
            strcpy(match[index].artist, list[index].artist);
            break;
        }
    }
    if (index == listSize)
        return false;
    else
        return true;
}

/*void nullCap(char lowerAlbum[MAX_CHAR], const Song list[])
{
    
}*/

bool searchArtistEntry(const char artist[], Song match[],
const Song list[], char tempDuration[TEMP_SIZE], int listSize)
{
    int artistIndex, inputIndex, index;
    //char inputLower[MAX_CHAR];
    char artistLower[MAX_CHAR];

    // sets input to lower case using temporary array
    for (inputIndex = 0; inputIndex <= MAX_CHAR; inputIndex++)
    {
        artistLower[inputIndex] = tolower(artist[inputIndex]);
    }

    for (index = 0; index < listSize; index++)
    {
        // sets song list artist array to lower case
        for (artistIndex = 0; artistIndex <= MAX_CHAR; artistIndex++)
        {
            match[index].artist[artistIndex] = tolower(list[index].artist[artistIndex]);
        }

        if (strcmp (artistLower, match[index].artist) == 0)
        {
            strcpy(match[index].artist, list[index].artist);
            strcpy(match[index].title, list[index].title);
            digitToChar(list, index, tempDuration);
            match[index].minutes = list[index].minutes;
            match[index].seconds = list[index].seconds;
            strcpy(match[index].album, list[index].album);
            break;
        }
    }
    if (index == listSize)
        return false;
    else
        return true;
}

void loadSongLibrary(const char fileName[], 
Song list[], int & listSize)
{
    ifstream in;
    char title[MAX_CHAR];
    char artist[MAX_CHAR];
    char album[MAX_CHAR];
    int minutes;
    int seconds;
    
    Song anEntry;

    in.open(fileName);
    if(!in)
    {
        in.clear();
        cerr << endl << "Failed to open " <<
        fileName << " for input!" << endl << endl;
        exit(1);
    }

    in.get(title, MAX_CHAR, ';');
    while (!in.eof())
    {
        in.get(); //remove ';'
        in.get(artist, MAX_CHAR, ';');
        in.get();
        in >> minutes;
        in.get();
        in >> seconds;
        in.get();
        in.get(album, MAX_CHAR, '\n');
        in.ignore(100, '\n'); //remove '\n'

        strcpy(anEntry.title, title);
        strcpy(anEntry.artist, artist);
        anEntry.minutes = minutes;
        anEntry.seconds = seconds;
        strcpy(anEntry.album, album);

        addEntry(anEntry, list, listSize);

        in.get(title, MAX_CHAR, ';'); //record next ifstream
    }
    in.close();
}

void saveSongLibrary(const char fileName[], 
const Song list[], int listSize)
{
    ofstream out;
    int index;

    out.open (fileName);
    if(!out)
    {
        out.clear();
        cerr << endl << "Failed to open " <<
        fileName << " for output!" << endl << endl;
        exit(1);
    }

    for(index = 0; index < listSize; index++)
    {
        out << list[index].title << ';' <<
        list[index].artist << ';' << 
        list[index].minutes << ';' <<
        list[index].seconds << ';' <<
        list[index].album << endl;
    }

    out.close();
}
