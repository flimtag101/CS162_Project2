#include <iostream>                 
#include <cstring>                   
#include "toolbox.h"  
 
using namespace std;                
 
int readInt(const char prompt[])
{
    int        intVal;
 
    cout << endl << prompt;
    cin >> intVal;
 
    //check if a valid integer is entered
    while (!cin)
    {
        //clear the error code for cin so that it can work again
        cin.clear();
 
        //throw away the garbage entered, e.g "None of your business."
        cin.ignore(100, '\n');
 
        //kindly ask again
        cout << "Invalid integer. Please try again: ";
        cin >> intVal;
    }
 
    //throw the rest of the line away, e.g. "99 Yippeeeeeee!"
    cin.ignore(100, '\n');
 
    return intVal;
}
 
void readString (const char prompt[], char inputStr[], int maxChar)
{
    cout << endl << prompt;
 
    //read until it either reaches the maxChar limit or encounters a '\n'
    cin.get(inputStr, maxChar, '\n');
    while(!cin)
    {
        cin.clear ();
        cin.ignore (100, '\n');
        cout << endl << prompt;
        cin.get(inputStr, maxChar, '\n');
    }
 
    //throw away the '\n'
    cin.ignore (100, '\n');
}
